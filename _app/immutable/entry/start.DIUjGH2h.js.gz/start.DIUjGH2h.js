import{l as o,a as r}from"../chunks/Du95fhYc.js";export{o as load_css,r as start};
