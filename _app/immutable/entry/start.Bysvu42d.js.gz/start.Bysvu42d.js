import{l as o,a as r}from"../chunks/BA4TWDhq.js";export{o as load_css,r as start};
