import{l as o,a as r}from"../chunks/OAP6Q1UH.js";export{o as load_css,r as start};
