import{l as o,a as r}from"../chunks/BJSCaWJ2.js";export{o as load_css,r as start};
