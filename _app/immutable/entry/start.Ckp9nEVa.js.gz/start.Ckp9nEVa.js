import{l as o,a as r}from"../chunks/CIKPbjYq.js";export{o as load_css,r as start};
