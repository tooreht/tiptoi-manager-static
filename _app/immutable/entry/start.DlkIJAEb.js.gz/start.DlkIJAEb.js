import{l as o,a as r}from"../chunks/CxZQNo64.js";export{o as load_css,r as start};
