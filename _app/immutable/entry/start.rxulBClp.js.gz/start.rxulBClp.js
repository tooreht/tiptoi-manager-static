import{l as o,a as r}from"../chunks/2b0eEZml.js";export{o as load_css,r as start};
