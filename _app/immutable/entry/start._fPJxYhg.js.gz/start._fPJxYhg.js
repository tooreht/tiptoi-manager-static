import{l as o,a as r}from"../chunks/CWA4A6pi.js";export{o as load_css,r as start};
