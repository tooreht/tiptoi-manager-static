import{l as o,a as r}from"../chunks/D0v4fxsS.js";export{o as load_css,r as start};
