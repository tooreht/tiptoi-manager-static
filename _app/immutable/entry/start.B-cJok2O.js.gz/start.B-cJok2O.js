import{l as o,a as r}from"../chunks/Co6mmRY9.js";export{o as load_css,r as start};
