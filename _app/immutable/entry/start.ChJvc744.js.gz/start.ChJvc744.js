import{l as o,a as r}from"../chunks/DJ-7M9Ke.js";export{o as load_css,r as start};
