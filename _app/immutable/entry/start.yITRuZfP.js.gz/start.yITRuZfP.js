import{l as o,a as r}from"../chunks/BguGf4Bn.js";export{o as load_css,r as start};
