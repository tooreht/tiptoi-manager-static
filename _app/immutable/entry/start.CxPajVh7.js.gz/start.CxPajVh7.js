import{l as o,a as r}from"../chunks/Bd1ACvD-.js";export{o as load_css,r as start};
