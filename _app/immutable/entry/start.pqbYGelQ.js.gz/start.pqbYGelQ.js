import{l as o,a as r}from"../chunks/ggR3Zlt8.js";export{o as load_css,r as start};
