import{l as o,a as r}from"../chunks/BxFvUs51.js";export{o as load_css,r as start};
