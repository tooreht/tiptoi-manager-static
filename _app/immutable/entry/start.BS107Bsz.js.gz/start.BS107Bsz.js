import{l as o,a as r}from"../chunks/CHW0yVcN.js";export{o as load_css,r as start};
