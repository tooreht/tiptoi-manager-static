import{l as o,a as r}from"../chunks/CQz4YIsA.js";export{o as load_css,r as start};
