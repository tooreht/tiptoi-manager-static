import{l as o,a as r}from"../chunks/BhPPSPPq.js";export{o as load_css,r as start};
