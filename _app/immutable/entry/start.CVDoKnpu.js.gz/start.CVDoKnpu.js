import{l as o,a as r}from"../chunks/Csrr5jyO.js";export{o as load_css,r as start};
