import{l as o,a as r}from"../chunks/-1qvx2x2.js";export{o as load_css,r as start};
