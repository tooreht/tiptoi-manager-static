import{l as o,a as r}from"../chunks/CZyl1tVH.js";export{o as load_css,r as start};
