import{l as o,a as r}from"../chunks/Dzk_oi6n.js";export{o as load_css,r as start};
