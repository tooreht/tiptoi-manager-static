import{l as o,a as r}from"../chunks/hKib08gJ.js";export{o as load_css,r as start};
