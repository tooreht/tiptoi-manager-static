import{l as o,a as r}from"../chunks/DeE493DV.js";export{o as load_css,r as start};
