import{l as o,a as r}from"../chunks/DNMhlo4M.js";export{o as load_css,r as start};
