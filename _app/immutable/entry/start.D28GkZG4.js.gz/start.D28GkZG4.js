import{l as o,a as r}from"../chunks/Dko0zDB9.js";export{o as load_css,r as start};
