import{l as o,a as r}from"../chunks/BoyV29vQ.js";export{o as load_css,r as start};
