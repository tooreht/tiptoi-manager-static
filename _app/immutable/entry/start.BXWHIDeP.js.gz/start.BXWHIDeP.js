import{l as o,a as r}from"../chunks/Bij_3E0v.js";export{o as load_css,r as start};
