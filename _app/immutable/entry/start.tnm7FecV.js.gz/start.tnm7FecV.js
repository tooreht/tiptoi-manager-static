import{l as o,a as r}from"../chunks/Dxcts4JX.js";export{o as load_css,r as start};
