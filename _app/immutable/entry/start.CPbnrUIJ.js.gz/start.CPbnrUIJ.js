import{l as o,a as r}from"../chunks/Cr2pWC5M.js";export{o as load_css,r as start};
