import{l as o,a as r}from"../chunks/Oofn6Kz5.js";export{o as load_css,r as start};
