import{l as o,a as r}from"../chunks/Bg_llOul.js";export{o as load_css,r as start};
