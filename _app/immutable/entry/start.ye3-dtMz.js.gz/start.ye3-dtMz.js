import{l as o,a as r}from"../chunks/Dt4MFZqj.js";export{o as load_css,r as start};
