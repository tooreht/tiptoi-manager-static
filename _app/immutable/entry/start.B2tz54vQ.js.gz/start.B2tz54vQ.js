import{l as o,a as r}from"../chunks/D_iveaUi.js";export{o as load_css,r as start};
