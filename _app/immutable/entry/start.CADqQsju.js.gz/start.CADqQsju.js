import{l as o,a as r}from"../chunks/d8zJsoaQ.js";export{o as load_css,r as start};
