import{l as o,a as r}from"../chunks/DII694fw.js";export{o as load_css,r as start};
