import{l as o,a as r}from"../chunks/Bi3_dO5t.js";export{o as load_css,r as start};
