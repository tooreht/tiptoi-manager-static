import{l as o,a as r}from"../chunks/Ba3wMr3N.js";export{o as load_css,r as start};
