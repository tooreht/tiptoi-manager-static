import{l as o,a as r}from"../chunks/La3nFSE4.js";export{o as load_css,r as start};
