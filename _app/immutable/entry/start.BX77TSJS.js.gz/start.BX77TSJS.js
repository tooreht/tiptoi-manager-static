import{l as o,a as r}from"../chunks/it5IhrE2.js";export{o as load_css,r as start};
