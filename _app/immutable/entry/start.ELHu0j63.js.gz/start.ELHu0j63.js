import{l as o,a as r}from"../chunks/B4Kr_0M5.js";export{o as load_css,r as start};
