import{l as o,a as r}from"../chunks/BDBX2bCp.js";export{o as load_css,r as start};
