import{l as o,a as r}from"../chunks/CIomo5ej.js";export{o as load_css,r as start};
