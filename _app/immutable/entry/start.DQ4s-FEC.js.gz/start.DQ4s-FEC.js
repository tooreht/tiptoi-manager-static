import{l as o,a as r}from"../chunks/C4QvgvtM.js";export{o as load_css,r as start};
