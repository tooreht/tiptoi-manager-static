import{l as o,a as r}from"../chunks/CnYjL9TB.js";export{o as load_css,r as start};
