import{l as o,a as r}from"../chunks/DYnOjI_w.js";export{o as load_css,r as start};
