import{l as o,a as r}from"../chunks/Cacc8uSz.js";export{o as load_css,r as start};
