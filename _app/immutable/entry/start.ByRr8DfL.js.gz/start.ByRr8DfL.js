import{l as o,a as r}from"../chunks/-8wklKE-.js";export{o as load_css,r as start};
