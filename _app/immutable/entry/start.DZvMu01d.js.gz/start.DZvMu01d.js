import{l as o,a as r}from"../chunks/UMrk_3nS.js";export{o as load_css,r as start};
