import{l as o,a as r}from"../chunks/B2pM5JST.js";export{o as load_css,r as start};
